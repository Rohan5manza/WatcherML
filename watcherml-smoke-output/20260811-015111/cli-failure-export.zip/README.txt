WatcherML run export
====================

Run: mac-smoke-20260811-015111-6f9a3e
Project: mac-smoke-20260811-015111
Status: failed

This bundle contains captured evidence and references. It does not claim
that the run is reproducible until the dataset, code, entrypoint, and
hardware constraints have been supplied and a rerun has been verified.

Suggested reconstruction steps:
1. Check out git commit e783ba4d4ac304b2bc97a123686966f86dda5067.
2. Review and apply working-tree.patch.
3. Create an isolated environment and install requirements.txt.
4. Restore a dataset matching the fingerprint in run.json.
5. Supply the training entrypoint and captured config.json.
6. Rerun in a fresh process and compare the declared verifier outputs.

Failure evidence is in failure-capsule.json. Its classification is
deterministic; it contains no LLM-generated diagnosis.
